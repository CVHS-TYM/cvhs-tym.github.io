def addSix():
    num = int(input("Number plz: "))
    num = num + 6
    return num
    
print (addSix())