import anything
anything.function noom()
anything.greetin()
anything.age()
